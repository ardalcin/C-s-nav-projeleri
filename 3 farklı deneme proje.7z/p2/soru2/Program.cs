﻿
using System;

namespace soru2
{
	class Program
	{
		public static void Main(string[] args)
		{
			int ctoplam=0,csayac=0,ttoplam=0,tsayac=0,esayac=0; //değişkenleri oluşturduk
			  int[] sayi = new int[30]; // 30 elemanlı diziyi oluşturuyoruz
            Random rnd = new Random(); // random sayı tanımını yaptık
            
 
            for (int i = 0; i < sayi.Length; i++) //dizi eleman uzunluğu kadar döngü oluşturuyoruz
            {
                sayi[i] = rnd.Next(1, 10); //bir ila 10 arası rastgele sayı üretiyoruz
               
            }
 
            foreach(int rakam in sayi) //foreach ile dizimizin elemanlarına değişken atıyoruz ve bunun ismini rakam veriyoruz	
            {
                
               if (rakam%2==0) { //eğer rakam ikiye bölündüğünde kalan  ise
            		csayac++; //sayaca 1 ekle
            		ctoplam+=rakam;// rakamları topla
           
                }
            	else if (rakam%2==1) { //eğer rakam ikiye bölündüğünde tek ise 
            		tsayac++;  //sayaca 1 ekle
            		ttoplam+=rakam;  // rakamları topla
            	}
            	if (rakam==3) { //eğer rakam üçe eşit ise
            		esayac++; //sayaca 1 ekle
            	}
          
            }
            Console.WriteLine("cift sayi adedi "+csayac+" toplamı = " +ctoplam); //ekrana yazdır
             Console.WriteLine("cift sayi adedi "+tsayac+" toplamı = " +ttoplam); //ekrana yazdır
              Console.WriteLine("sayı dizisi içinde üçe eşit "+esayac+" eleman vardır"); //ekrana yazdır
           
            Console.ReadKey();
		}
	}
}