﻿using System;

namespace Soru1
{
	class Program
	{
		
		public static void Main(string[] args)
		{
			int yuzler,onlar,birler,kupler;
			 for (int i = 100; i <= 999; i++) // 100 ile 999 arasındaki sayıları tek tek alıyor
        {

            yuzler = i / 100; //aldığı sayının yüzler basamağını buluyor

            onlar = (i % 100) / 10; // aldığı sayının onlar basamağını buluyor

            birler = i % 10; //aldığı sayının birler basamağını buluyor

            kupler= (yuzler * yuzler * yuzler) + (onlar * onlar * onlar) + (birler * birler * birler); // yüzler onlar ve birler basamaklarının küpünü alıp topluyor ve kupler adlı değişkene aktarıyor

            if (kupler == i) //eğer kupler döngüde oluşan sayıya eşit ise
            	Console.WriteLine(i.ToString()  +" = " +yuzler*yuzler*yuzler+" + "+onlar*onlar*onlar+ " + "+birler*birler*birler+" kendisine eşittir");
        }   		//ekrana yazdırıyor 
        Console.ReadLine();
}
		}
	}
