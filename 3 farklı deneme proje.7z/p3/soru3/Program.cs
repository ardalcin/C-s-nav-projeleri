﻿
using System;

namespace soru3
{
	class Program
	{
		public static void Main(string[] args)
		{
			int elimizdekisayi = 8, buyuks=0, yapılanislem=0,islem;
			// elimize sekiz sayısını aldık ve bunun elimizdekisayi adlı değişkene aktardık
			// bunun yanında istenilen en büyük sayıyı atamak için buyuks adlı bir değişken oluşturduk
			// yapılan işlemleri sayması için yapılanislem adında bir değişken daha oluşturduk
            
          

           
            do{  //do while döngüsü oluşturarak yapılan işlemi istenilen sonuç alınana kadar yürütmesini istiyoruz
                if (elimizdekisayi % 2 == 1)  // if satırında elimizdeki sayının tekmi çiftmi olduğuna bakıyoruz
                	//eğer tek ise yani 2 ye böldüğümüzde kalan 1 ise
                {
                    islem = (elimizdekisayi * 3) + 1; // islem adlı bir değişken tanımlayıp yaptığımız işlemi bu değişkene aktarıyoruz -- 3 ile çarp 1 ekle
                    elimizdekisayi = islem; //yapılan işlemdeki sonucu elimizdeki sayının yerine aktarıyoruz
                    yapılanislem++;  //ve yapılan işlem sayısına bir ekliyoruz
                    Console.WriteLine(elimizdekisayi);//elimizde tuttuğumuz sayıyı ekrana yazdırıyoruz

                    if (elimizdekisayi>buyuks) //eğer elimizde kalan sayı büyüksayıdan büyükse
                    {
                        buyuks = elimizdekisayi;	//elimizdek sayıyı büyük sayıya aktarıyoruz
                    }
                }
                else
                {
                  islem = (elimizdekisayi / 2); // eğer çıkan sayı çift ise sayıyı ikiye bölüyoruz ve bunu işlem değişkenine aktarıyoruz
                    elimizdekisayi = islem; // bu değeri elimizdeki sayıya aktarıyoruz
                    yapılanislem++;//her işlem yapıldığında bir arttırıyoruz yapılan işlemi
                    Console.WriteLine(elimizdekisayi);//ekrana yazdırıyoruz

                    if (elimizdekisayi > buyuks) //eğer elimizde kalan sayı büyüksayıdan büyükse
                    {
                        buyuks = elimizdekisayi; //elimizdek sayıyı büyük sayıya aktarıyoruz
                    }
                }

                

            } while (elimizdekisayi != 1); 


            Console.WriteLine("İşlem Sayısı Adeti: " + yapılanislem);
            Console.WriteLine("En Büyük Sayı: " + buyuks);
            Console.ReadKey();
            //sayılarıda ekrana yazdırarak bitiriyoruz..
		}
	}

}